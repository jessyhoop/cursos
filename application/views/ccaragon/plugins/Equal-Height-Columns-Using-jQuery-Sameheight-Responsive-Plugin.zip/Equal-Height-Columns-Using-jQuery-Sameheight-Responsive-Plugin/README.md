# Jquery Sameheight Responsive
This jquery script sets the height of all selected elements to the same height as the tallest one. Perfect for creating columns with equal height.

See demo: http://www.runesa.nl/demo/sameheight/example.html
## Usage
>$('.column').sameheight();

### Copyright
Diederik Lascaris 2011-2014
Runesa
### License
Licensed under MIT licence
